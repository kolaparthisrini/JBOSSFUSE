package com.apache.cxf.formparam.service;

import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

@Service("playerService")
public class PlayerServiceImpl implements IPlayerService {

	/**
	 * this method takes three argument from FormParam and returns a Response
	 */
	public Response getPlayerInfo(String playerName, int age, int matches) {

		String playerInfo = "Player with information " + "[name=" + playerName +  ", age=" + age + ", matches=" + matches + "]" + " added to the database";
		return Response.status(200).entity(playerInfo).build();
	}
}