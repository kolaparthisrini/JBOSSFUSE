package com.apache.cxf.formparam.service;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/player")
public interface IPlayerService {

	// http://localhost:8080/ApacheCXF-FormParam/services/player/addinfo
	@POST
	@Path("/addinfo")
	public Response getPlayerInfo(
			@FormParam("name") String playerName, 
			@FormParam("age") int age, 
			@FormParam("matches") int matches);
}