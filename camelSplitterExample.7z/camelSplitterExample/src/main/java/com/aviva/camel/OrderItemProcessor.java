package com.aviva.camel;

public class OrderItemProcessor {
    public void process(OrderItem item) {
        item.process();
    }
}
