package com.caps;

import javax.jws.WebService;

@WebService(endpointInterface = "com.caps.ChangeStudent")
public class ChangeStudentImp implements ChangeStudent {
    public Student changeName(Student student) {
      student.setName("Hello "+student.getName());
      return student;
    }
}