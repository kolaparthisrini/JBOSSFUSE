package com.example.RouteService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelBootApplication.class, args);
	}
}
