package com.example.RouteService;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class CamelRoute extends RouteBuilder {
	@Override
	public void configure() throws Exception {
		from("direct:firstRoute").log("Camel body: i am in camel session");
	}
}
